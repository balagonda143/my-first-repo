package jsp.SpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCurdOperationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCurdOperationApplication.class, args);
	}

}
